#include "bot_ui.h"
#include "bot_ui_motion.h"
#include <stdio.h>
#include <string.h>
#ifdef CONFIG_BOT_DEV_SIM
void stats_dev_build(lv_obj_t *s);void stats_dev_refresh(void);
#endif
static lv_obj_t *body,*title,*tabs[3],*indicator;
static int active_tab=-1;
void stats_refresh(void);
static const char *tool_name(const char *s){
 if(strstr(s,"read") || strstr(s,"Read"))return "文件读取";
 if(strstr(s,"write") || strstr(s,"edit") || strstr(s,"patch"))return "文件修改";
 if(strstr(s,"exec") || strstr(s,"shell") || strstr(s,"terminal"))return "终端执行";
 if(strstr(s,"search") || strstr(s,"web"))return "资料检索";
 if(strstr(s,"agent") || strstr(s,"task"))return "子任务";
 return "其他工具";
}
static lv_obj_t *line(lv_obj_t *s,const char *t,int y,bool large) {
 lv_obj_t *l=lv_label_create(s);lv_label_set_text(l,t);lv_obj_set_size(l,326,large?34:30);lv_obj_set_pos(l,70,y);
 lv_obj_set_style_text_font(l,large?&bot_font_24:&bot_font_22,0);lv_obj_set_style_text_color(l,lv_color_hex(large?0xddeaf2:0x9aa6b3),0);
 lv_obj_set_style_text_align(l,LV_TEXT_ALIGN_CENTER,0);lv_label_set_long_mode(l,LV_LABEL_LONG_DOT);return l;
}
static const char *metric_name(bot_metric_key_t k){static const char *n[]={"轮次","工具调用","请求","输入 Token","输出 Token","总 Token","工作时长","费用","上下文 Token"};return n[k];}
static const char *quality(bot_metric_quality_t q){static const char *n[]={"精确","估算","手动","数据不可用","模拟数据"};return n[q];}
static bool stale(bool has,uint64_t asof,uint32_t after){uint64_t current=g_ui.model.stats.sent_at_ms+(uint32_t)(lv_tick_get()-g_ui.stats_received_ms);return has && (current<asof || current-asof>after);}
void stats_refresh(void) {
#ifdef CONFIG_BOT_DEV_SIM
 if(g_ui.dev_sim){stats_dev_refresh();return;}
#endif
 if(!body)return;
 bot_model_t *m=&g_ui.model;char b[180];lv_obj_clean(body);
 lv_label_set_text(title,bot_ui_agent_name(m->selected_agent));
 for(unsigned i=0;i<3;i++)lv_obj_set_style_text_color(tabs[i],lv_color_hex(i==g_ui.stats_tab?0xddeaf2:0x717b87),0);
 if(active_tab!=(int)g_ui.stats_tab) {
  int x=81+g_ui.stats_tab*108;
  if(active_tab<0)lv_obj_set_x(indicator,x);else bot_ui_indicator_move(indicator,x);
  active_tab=g_ui.stats_tab;
 }

 if(m->state!=BOT_MS_ONLINE){line(body,bot_ui_health(m->selected_agent),199,true);line(body,"等待 Mac Bridge 连接",245,false);return;}
 if(g_ui.stats_tab==0) {
  if(!m->has_focus){line(body,"暂无任务数据",185,true);line(body,bot_ui_health(m->selected_agent),231,false);}
  else {
   bot_focus_t *f=&m->focus;
   line(body,bot_ui_state_name(f->state),145,true);
   snprintf(b,sizeof(b),"任务 %.14s",f->run_id);line(body,f->has_run_id && f->run_id[0]?b:"暂无任务标识",187,false);
   const char *reason=f->reason==BOT_REASON_APPROVAL?"等待批准":f->reason==BOT_REASON_INPUT?"等待输入":f->reason==BOT_REASON_FAILED?"任务执行失败":f->reason==BOT_REASON_CANCELLED?"任务已取消":f->reason==BOT_REASON_COMPLETED?"任务已完成":"";
   if(f->state==BOT_STATE_TOOL){snprintf(b,sizeof(b),"工具 · %s",tool_name(f->tool));reason=b;}
   line(body,reason,224,false);
   snprintf(b,sizeof(b),"运行时间 %llu 秒",(unsigned long long)f->run_elapsed_ms/1000);line(body,f->has_run_id?b:"运行时间未知",260,false);
   snprintf(b,sizeof(b),"活跃任务 %u",f->active_sessions);line(body,f->state==BOT_STATE_UNKNOWN?"活跃任务未知":b,296,false);
   snprintf(b,sizeof(b),"来源 · %s",f->quality==BOT_QUALITY_OBSERVED?"实时观测":f->quality==BOT_QUALITY_INFERRED?"推断":"未核实");line(body,b,332,false);
   line(body,f->stale?"数据已过期":bot_ui_health(m->selected_agent),370,false);
  }
 } else if(!m->has_stats) {line(body,g_ui.stats_tab==2?"暂无配额来源":"暂无今日数据",200,true);line(body,bot_ui_health(m->selected_agent),245,false);}
 else if(g_ui.stats_tab==1) {
  bot_stats_t *s=&m->stats;
  if(s->scope_kind!=0){line(body,"暂无今日数据",210,true);return;}
  if(!s->metric_count)line(body,"暂无今日数据",205,true);
  for(unsigned i=0;i<s->metric_count && i<3;i++) {
   bot_metric_t *v=&s->metrics[i];
   if(v->has_value && v->key==BOT_MKEY_ACTIVE_TIME_MS)snprintf(b,sizeof(b),"工作时长  %.0f 秒",v->value/1000);
   else if(v->has_value && v->key==BOT_MKEY_COST_USD_MICROS)snprintf(b,sizeof(b),"费用  $%.4f",v->value/1000000);
   else if(v->has_value)snprintf(b,sizeof(b),"%s  %.0f",metric_name(v->key),v->value);else snprintf(b,sizeof(b),"%s  —",metric_name(v->key));
   line(body,b,132+i*78,true);
   snprintf(b,sizeof(b),"%s · %s%s",stale(v->has_as_of_ms,v->as_of_ms,v->stale_after_ms)?"数据已过期":quality(v->quality),v->source[0]?v->source:"来源未知",v->coverage!=BOT_COV_COMPLETE?" · 不完整":"");line(body,b,167+i*78,false);
  }
  line(body,"未提供的数据保持空缺",374,false);
 } else {
  bot_stats_t *s=&m->stats;
  if(!s->quota_count)line(body,"暂无配额来源",205,true);
  for(unsigned i=0;i<s->quota_count;i++) {
   bot_quota_t *q=&s->quotas[i];int y=133+i*124;
   line(body,q->label,y,false);
   if(q->availability!=BOT_QAVAIL_AVAILABLE)snprintf(b,sizeof(b),"%s",q->availability==BOT_QAVAIL_ERROR?"配额读取错误":q->availability==BOT_QAVAIL_NEEDS_AUTH?"配额需要登录":"来源不支持配额");
   else if(q->kind==BOT_QKIND_UNLIMITED)snprintf(b,sizeof(b),"不限额度");
   else if(q->has_used_pct)snprintf(b,sizeof(b),"已用 %.1f%%",q->used_pct);
   else if(q->has_remaining && q->unit==BOT_QUNIT_USD_MICROS)snprintf(b,sizeof(b),"剩余 $%.2f USD",q->remaining/1000000);
   else if(q->has_remaining)snprintf(b,sizeof(b),"剩余 %.0f %s",q->remaining,q->unit==BOT_QUNIT_CREDIT?"credit":q->unit==BOT_QUNIT_TOKEN?"Token":q->unit==BOT_QUNIT_REQUEST?"次请求":q->unit==BOT_QUNIT_PERCENT?"%":"");
   else snprintf(b,sizeof(b),"额度未知");
   line(body,b,y+35,true);
   snprintf(b,sizeof(b),"%s · %s",stale(q->has_as_of_ms,q->as_of_ms,q->stale_after_ms)?"数据已过期":quality(q->quality),q->source[0]?q->source:"来源未知");line(body,b,y+72,false);
  }
  line(body,"配额按来源范围统计",374,false);
 }
}
static void deleted(lv_event_t *e){if(lv_event_get_target_obj(e)==body){body=NULL;title=NULL;indicator=NULL;active_tab=-1;for(int i=0;i<3;i++)tabs[i]=NULL;}}
void stats_build(lv_obj_t *s) {
#ifdef CONFIG_BOT_DEV_SIM
 if(g_ui.dev_sim){stats_dev_build(s);return;}
#endif
 title=line(s,"",62,true);
 static const char *names[]={"当前任务","今日统计","额度"};
 for(unsigned i=0;i<3;i++){
  tabs[i]=line(s,names[i],99,false);lv_obj_set_pos(tabs[i],71+i*108,99);lv_obj_set_size(tabs[i],108,36);
  lv_obj_remove_flag(tabs[i],LV_OBJ_FLAG_CLICKABLE);
  lv_obj_set_style_bg_color(tabs[i],lv_color_hex(0x243447),0);lv_obj_set_style_radius(tabs[i],8,0);
 }
 indicator=lv_obj_create(s);lv_obj_remove_style_all(indicator);lv_obj_set_pos(indicator,81,133);lv_obj_set_size(indicator,88,2);
 lv_obj_set_style_bg_color(indicator,lv_color_hex(0xddeaf2),0);lv_obj_set_style_bg_opa(indicator,255,0);
 lv_obj_remove_flag(indicator,LV_OBJ_FLAG_SCROLLABLE|LV_OBJ_FLAG_CLICKABLE);active_tab=-1;
 body=lv_obj_create(s);lv_obj_remove_style_all(body);lv_obj_set_size(body,466,466);lv_obj_remove_flag(body,LV_OBJ_FLAG_SCROLLABLE|LV_OBJ_FLAG_CLICKABLE);lv_obj_add_event_cb(body,deleted,LV_EVENT_DELETE,NULL);lv_obj_move_background(body);stats_refresh();
}

void stats_press(int tab,bool pressed) {
#ifdef CONFIG_BOT_DEV_SIM
 if(g_ui.dev_sim){extern void stats_dev_press(int,bool);stats_dev_press(tab,pressed);return;}
#endif
 if(tab>=0 && tab<3)bot_ui_press_feedback(tabs[tab],pressed);
}
